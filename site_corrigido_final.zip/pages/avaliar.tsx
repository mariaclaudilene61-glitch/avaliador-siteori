export default function Avaliar() {
  return (
    <main>
      <h1>Faça sua avaliação</h1>
      <p>Responda às perguntas e ganhe pontos!</p>
    </main>
  );
}