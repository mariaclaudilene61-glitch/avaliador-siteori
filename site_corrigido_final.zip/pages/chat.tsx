export default function Chat() {
  return (
    <main>
      <h1>Chat Exclusivo</h1>
      <p>Bem-vindo ao chat para usuários com +50 mil pontos!</p>
    </main>
  );
}