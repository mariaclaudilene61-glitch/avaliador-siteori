# Site de Avaliação de Livros

Instruções de deploy na Vercel incluídas.