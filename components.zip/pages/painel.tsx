export default function Painel() {
  return (
    <main>
      <h1>Painel do Usuário</h1>
      <p>Veja suas avaliações e pontos acumulados.</p>
    </main>
  );
}