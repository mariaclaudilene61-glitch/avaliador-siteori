export default function Politica() {
  return (
    <main>
      <h1>Política de Pagamento</h1>
      <p>Veja como funciona o sistema de pontos e resgates.</p>
    </main>
  );
}