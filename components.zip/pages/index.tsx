import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>VIP Avaliador</title>
      </Head>
      <main>
        <h1>Bem-vindo ao VIP Avaliador</h1>
        <p>Ganhe pontos avaliando livros pouco conhecidos!</p>
      </main>
    </>
  );
}